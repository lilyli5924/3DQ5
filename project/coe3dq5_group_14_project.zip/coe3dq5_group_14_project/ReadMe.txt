Status of each milestone:
Milestone 1: completed
Milestone 2: completed
Milestone 3: able to go through simulation and on board testing by reading from SRAM address 0 and directly write to pre-IDCT section (76800). No integration is implemented.